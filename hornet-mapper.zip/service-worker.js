
const CACHE = 'hornet-mapper-v1';
/* full service worker code here */
